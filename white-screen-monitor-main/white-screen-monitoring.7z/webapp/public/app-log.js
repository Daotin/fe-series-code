module.exports={
    props:{
        data:Array,
        fetchAppRunningLogs:Function
    }
}